//
//  ViewController.swift
//  TableViewDemo_ApexaMistry
//
//  Created by Apexa Mistry on 19/02/21.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var lblName: UILabel!
  var name : String = ""
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    //navigationItem.title = ""
    lblName.text = name
  }


}

